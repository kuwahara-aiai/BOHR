﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPGGame
{

    public class RPG : Game
    {

        public override void Play()
        {
            Console.WriteLine("Play内容を書くよ");
        }

    }

}

