﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp0302
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //変数による演算結果
            int a = 6, b = 3;
            double avg;
            avg = (a + b) / 2.0;
            Console.Write("{0}と{1}の平均値", a, b);
            Console.WriteLine(avg);
            Console.WriteLine("--------------------------------");
            //if文
            int c = 0;
            if (c > 0)
            {
                Console.WriteLine("aは正の数です。");
            }else if(a == 0){
                Console.WriteLine("aは0です");
            }
            else
            {
                Console.WriteLine("aは0以下です。");
            }
            Console.WriteLine("--------------------------------");
        }
    }
}
