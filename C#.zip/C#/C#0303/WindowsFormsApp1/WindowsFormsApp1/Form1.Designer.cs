﻿namespace WindowsFormsApp1
{
    partial class FormSample
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージド リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.inputText = new System.Windows.Forms.TextBox();
            this.outputText = new System.Windows.Forms.TextBox();
            this.runButton = new System.Windows.Forms.Button();
            this.inputLabel = new System.Windows.Forms.Label();
            this.outputLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // inputText
            // 
            this.inputText.Location = new System.Drawing.Point(40, 50);
            this.inputText.Name = "inputText";
            this.inputText.Size = new System.Drawing.Size(400, 19);
            this.inputText.TabIndex = 0;
            this.inputText.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // outputText
            // 
            this.outputText.Location = new System.Drawing.Point(40, 120);
            this.outputText.Name = "outputText";
            this.outputText.ReadOnly = true;
            this.outputText.Size = new System.Drawing.Size(400, 19);
            this.outputText.TabIndex = 1;
            this.outputText.TextChanged += new System.EventHandler(this.outText_TextChanged);
            // 
            // runButton
            // 
            this.runButton.Location = new System.Drawing.Point(175, 190);
            this.runButton.Name = "runButton";
            this.runButton.Size = new System.Drawing.Size(120, 50);
            this.runButton.TabIndex = 2;
            this.runButton.Text = "実行";
            this.runButton.UseVisualStyleBackColor = true;
            this.runButton.Click += new System.EventHandler(this.runButton_Click);
            // 
            // inputLabel
            // 
            this.inputLabel.AutoSize = true;
            this.inputLabel.Location = new System.Drawing.Point(38, 35);
            this.inputLabel.Name = "inputLabel";
            this.inputLabel.Size = new System.Drawing.Size(29, 12);
            this.inputLabel.TabIndex = 3;
            this.inputLabel.Text = "入力";
            // 
            // outputLabel
            // 
            this.outputLabel.AutoSize = true;
            this.outputLabel.Location = new System.Drawing.Point(40, 95);
            this.outputLabel.Name = "outputLabel";
            this.outputLabel.Size = new System.Drawing.Size(29, 12);
            this.outputLabel.TabIndex = 4;
            this.outputLabel.Text = "出力";
            this.outputLabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // FormSample
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 311);
            this.Controls.Add(this.outputLabel);
            this.Controls.Add(this.inputLabel);
            this.Controls.Add(this.runButton);
            this.Controls.Add(this.outputText);
            this.Controls.Add(this.inputText);
            this.Location = new System.Drawing.Point(40, 90);
            this.Name = "FormSample";
            this.Text = "フォームサンプル";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox inputText;
        private System.Windows.Forms.TextBox outputText;
        private System.Windows.Forms.Button runButton;
        private System.Windows.Forms.Label inputLabel;
        private System.Windows.Forms.Label outputLabel;
    }
}

