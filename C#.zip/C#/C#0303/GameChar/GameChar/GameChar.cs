﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game
{
    public class GameChar
    {
        protected string name="勇者";
        protected int hp=50;

        public GameChar(string name, int hp)
        {
            this.name = name;
            this.hp = hp;
        }
        public void Fight()
        {
            if (this.hp >= 0 && hp != 50)
            {
                Console.WriteLine("\r\n{0}:「まだまだ！！」\r\n", name);
            }
            Random r = new Random();
            int attack = r.Next(1, 10);
            Console.WriteLine("{0}は{1}の攻撃を受けた", Name, attack);
            Attack(attack);
            ShowHP();
            Console.WriteLine("------------------------------");
            Console.WriteLine("続ける　>>Press enter Key");
            Console.ReadLine();

        }
        public virtual void Attack(int damage)
        {
            this.hp -= damage;
            if (this.hp <= 0)
            {
                hp = 0;
                Console.WriteLine("{0}は倒れた", name);
            }
        }
        public void ShowHP()
        {
            Console.WriteLine("{0}のHP：{1}", name, hp);

        }
        public void EndMessage()
        {
            Console.WriteLine("{0}は倒れてしまった、、、！\r\n" +
                "*** ゲームオーバー ***", name);
            Console.WriteLine("------------------------------");
        }
        public string Name
        {
            get { return name; }
        }
        public int HP
        {
            get { return hp; }
        }

    }

}
