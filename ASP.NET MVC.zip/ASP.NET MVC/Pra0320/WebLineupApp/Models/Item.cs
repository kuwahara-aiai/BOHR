﻿using System.ComponentModel.DataAnnotations;

namespace WebLineupApp.Models
{
    public class Item
    {
        public int Id { get; set; }
        public string? Name { get; set; }

        public DateTime ReleaseDate { get; set; }
        public int Price { get; set; }
        public int Carolie { get; set; }
        public string? Genre { get; set; }

    }
}

